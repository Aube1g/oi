#!/usr/bin/env python3
"""XLI Gradient Demo — zero dependencies, pure ANSI True Color."""

RESET = "\033[0m"
BOLD = "\033[1m"

def lerp(a, b, t):
    return int(a + (b - a) * t)

def gradient_line(text, r1, g1, b1, r2, g2, b2, bold=False):
    chars = list(text)
    n = max(len(chars) - 1, 1)
    out = []
    for i, ch in enumerate(chars):
        t = i / n
        r = lerp(r1, r2, t)
        g = lerp(g1, g2, t)
        b = lerp(b1, b2, t)
        prefix = BOLD if bold else ""
        out.append(f"{prefix}\033[38;2;{r};{g};{b}m{ch}")
    out.append(RESET)
    return "".join(out)

def gradient_box(lines, r1, g1, b1, r2, g2, b2):
    width = max(len(l) for l in lines) if lines else 20
    n = max(len(lines) + 1, 1)
    out = []
    # top border
    out.append(gradient_line("┌" + "─" * (width + 2) + "┐", r1, g1, b1, r2, g2, b2))
    for i, line in enumerate(lines):
        t = (i + 1) / n
        r, g, b = lerp(r1, r2, t), lerp(g1, g2, t), lerp(b1, b2, t)
        padded = line.ljust(width)
        out.append(f"\033[38;2;{r};{g};{b}m│ {padded} │{RESET}")
    # bottom border
    out.append(gradient_line("└" + "─" * (width + 2) + "┘", r1, g1, b1, r2, g2, b2))
    return "\n".join(out)

# XLI Palette
DARK   = (90, 24, 154)     # #5A189A Deep Violet
PURPLE = (157, 78, 221)    # #9D4EDD XLI Purple
NEON   = (224, 170, 255)   # #E0AAFF Neon Magenta

print()
print(gradient_line("  ✦  X L I   G R A D I E N T   E N G I N E  ✦  ", *DARK, *NEON, bold=True))
print()

# Horizontal gradient bar
bar = "█" * 60
print(gradient_line(bar, *DARK, *NEON))
print()

# Thin line
thin = "─" * 60
print(gradient_line(thin, *PURPLE, *NEON))
print()

# Box with vertical gradient
box_lines = [
    "GET https://httpbin.org/get",
    "Status: 200 OK",
    "Server: XLI/1.0",
    "Engine: Pure ANSI True Color",
]
print(gradient_box(box_lines, *DARK, *NEON))
print()

# Per-character body demo
body = '{"xli": "gradient engine", "style": "purple neon", "deps": 0}'
print(gradient_line("Response:", *PURPLE, *NEON, bold=True))
print(gradient_line(body, *DARK, *NEON))
print()

# Spinner animation frames
frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
import time
print(gradient_line("Installing httpx...", *PURPLE, *NEON, bold=True))
for step in range(30):
    t = step / 29
    r, g, b = lerp(DARK[0], NEON[0], t), lerp(DARK[1], NEON[1], t), lerp(DARK[2], NEON[2], t)
    filled = int(30 * (step + 1) / 30)
    empty = 30 - filled
    bar_str = "█" * filled + "░" * empty
    spinner = frames[step % len(frames)]
    pct = int(100 * (step + 1) / 30)
    line = f"  \033[38;2;{r};{g};{b}m{spinner} [{bar_str}] {pct:3d}%{RESET}"
    print(f"\r{line}", end="", flush=True)
    time.sleep(0.05)

print()
print(gradient_line("  ✅ Done!", *PURPLE, *NEON, bold=True))
print()
