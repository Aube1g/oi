#!/usr/bin/env python3
"""Force pytest to display the gradient render output."""

RESET = "\033[0m"
BOLD = "\033[1m"

def lerp(a, b, t):
    return int(a + (b - a) * t)

def gradient_line(text, r1, g1, b1, r2, g2, b2, bold=False):
    chars = list(text)
    n = max(len(chars) - 1, 1)
    out = []
    for i, ch in enumerate(chars):
        t = i / n
        r = lerp(r1, r2, t)
        g = lerp(g1, g2, t)
        b = lerp(b1, b2, t)
        prefix = BOLD if bold else ""
        out.append(f"{prefix}\033[38;2;{r};{g};{b}m{ch}")
    out.append(RESET)
    return "".join(out)

def gradient_box(lines, r1, g1, b1, r2, g2, b2):
    width = max(len(l) for l in lines) if lines else 20
    n = max(len(lines) + 1, 1)
    out = []
    out.append(gradient_line("┌" + "─" * (width + 2) + "┐", r1, g1, b1, r2, g2, b2))
    for i, line in enumerate(lines):
        t = (i + 1) / n
        r, g, b = lerp(r1, r2, t), lerp(g1, g2, t), lerp(b1, b2, t)
        padded = line.ljust(width)
        out.append(f"\033[38;2;{r};{g};{b}m│ {padded} │{RESET}")
    out.append(gradient_line("└" + "─" * (width + 2) + "┘", r1, g1, b1, r2, g2, b2))
    return "\n".join(out)

DARK   = (90, 24, 154)
PURPLE = (157, 78, 221)
NEON   = (224, 170, 255)

def test_gradient_demo_output():
    parts = []
    parts.append("")
    parts.append(gradient_line("  ✦  X L I   G R A D I E N T   E N G I N E  ✦  ", *DARK, *NEON, bold=True))
    parts.append("")
    parts.append(gradient_line("█" * 50, *DARK, *NEON))
    parts.append("")
    parts.append(gradient_line("─" * 50, *PURPLE, *NEON))
    parts.append("")
    box_lines = [
        "GET https://httpbin.org/get",
        "Status: 200 OK",
        "Server: XLI/1.0",
        "Engine: Pure ANSI True Color",
    ]
    parts.append(gradient_box(box_lines, *DARK, *NEON))
    parts.append("")
    body = '{"xli": "gradient engine", "style": "purple neon", "deps": 0}'
    parts.append(gradient_line("Response:", *PURPLE, *NEON, bold=True))
    parts.append(gradient_line(body, *DARK, *NEON))
    parts.append("")
    # Static progress bar snapshot (no animation in test)
    filled = 20
    empty = 30 - filled
    bar_str = "█" * filled + "░" * empty
    parts.append(gradient_line(f"  ⠋ [{bar_str}]  66%", *PURPLE, *NEON, bold=True))
    parts.append("")
    parts.append(gradient_line("  ✅ Done!", *PURPLE, *NEON, bold=True))
    parts.append("")

    output = "\n".join(parts)
    print(output)
    assert False, f"\n{output}"
