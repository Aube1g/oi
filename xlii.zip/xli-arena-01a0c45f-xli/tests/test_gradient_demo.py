#!/usr/bin/env python3
"""Force pytest to show rendered output via assertion message."""

def test_show_render():
    import sys
    sys.path.insert(0, ".")
    from xli.ui.installer import render_gradient_line, render_dep_card, render_summary
    from xli.core.deps_installer import DependencyInfo

    parts = []
    parts.append("\n=== XLI INSTALLER UI DEMO ===\n")
    parts.append("1) Gradient line:")
    parts.append(render_gradient_line(50))
    parts.append("")
    parts.append("2) Gradient with text:")
    parts.append(render_gradient_line(50, "INSTALLING"))
    parts.append("")
    dep = DependencyInfo(
        name="httpx",
        description="Modern async HTTP client for Python",
        why_needed="Web search, API calls to SearXNG",
        required_by=["web_search", "fetch_page"],
    )
    parts.append("3) Dependency card:")
    parts.append(render_dep_card(dep))
    parts.append("")
    parts.append("4) Summary:")
    parts.append(render_summary({"httpx": True, "rich": True, "textual": False}))

    output = "\n".join(parts)
    # Force failure so pytest prints the output in the traceback
    assert False, f"\n{output}"
