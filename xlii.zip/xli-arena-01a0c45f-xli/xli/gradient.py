"""XLI Gradient Engine.

Generates smooth ANSI True Color gradients for terminal output.
Style reference: XLI Purple (#9D4EDD) -> Neon Magenta (#E0AAFF).
"""

from __future__ import annotations

RESET = "\033[0m"
BOLD = "\033[1m"

# ── XLI Palette ────────────────────────────────────────────────
XLI_DARK_VIOLET: tuple[int, int, int] = (90, 24, 154)    # #5A189A
XLI_PURPLE: tuple[int, int, int] = (157, 78, 221)         # #9D4EDD
XLI_NEON_MAGENTA: tuple[int, int, int] = (224, 170, 255)  # #E0AAFF


def _lerp(start: int, end: int, t: float) -> int:
    """Linear interpolation between two integers."""
    return int(start + (end - start) * t)


def interpolate_color(
    color_start: tuple[int, int, int],
    color_end: tuple[int, int, int],
    t: float,
) -> tuple[int, int, int]:
    """Interpolate between two RGB colors. `t` is from 0.0 to 1.0."""
    return (
        _lerp(color_start[0], color_end[0], t),
        _lerp(color_start[1], color_end[1], t),
        _lerp(color_start[2], color_end[2], t),
    )


def ansi_fg(rgb: tuple[int, int, int]) -> str:
    """Return ANSI True Color foreground escape sequence for an RGB tuple."""
    return f"\033[38;2;{rgb[0]};{rgb[1]};{rgb[2]}m"


def gradient_text(
    text: str,
    start: tuple[int, int, int] = XLI_DARK_VIOLET,
    end: tuple[int, int, int] = XLI_NEON_MAGENTA,
    bold: bool = False,
) -> str:
    """Apply a smooth per-character ANSI True Color gradient to `text`.

    Each character gets its own interpolated RGB value between `start` and `end`.
    Newlines are preserved without color codes to avoid breaking terminal layout.
    """
    if not text:
        return text

    # Filter out newlines for correct step calculation
    chars = list(text)
    printable_indices = [i for i, c in enumerate(chars) if c != "\n"]
    steps = max(len(printable_indices) - 1, 1)

    prefix = BOLD if bold else ""
    result: list[str] = []

    color_idx = 0
    for char in chars:
        if char == "\n":
            result.append(f"{RESET}{char}")
            continue

        t = color_idx / steps
        rgb = interpolate_color(start, end, t)
        result.append(f"{prefix}{ansi_fg(rgb)}{char}")
        color_idx += 1

    result.append(RESET)
    return "".join(result)


def gradient_box(
    lines: list[str],
    start: tuple[int, int, int] = XLI_PURPLE,
    end: tuple[int, int, int] = XLI_NEON_MAGENTA,
) -> str:
    """Wrap lines in a Unicode box with a vertical gradient applied to borders and text."""
    if not lines:
        return ""

    max_width = max(len(line) for line in lines)
    total_steps = max(len(lines) + 1, 1)

    result: list[str] = []

    # Top border
    rgb_top = start
    result.append(f"{ansi_fg(rgb_top)}┌{'─' * (max_width + 2)}┐{RESET}")

    # Content lines
    for i, line in enumerate(lines):
        t = (i + 1) / total_steps
        rgb = interpolate_color(start, end, t)
        padded = line.ljust(max_width)
        result.append(f"{ansi_fg(rgb)}│ {padded} │{RESET}")

    # Bottom border
    rgb_bottom = end
    result.append(f"{ansi_fg(rgb_bottom)}└{'─' * (max_width + 2)}┘{RESET}")

    return "\n".join(result)
