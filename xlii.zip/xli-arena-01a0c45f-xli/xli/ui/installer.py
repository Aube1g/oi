#!/usr/bin/env python3
"""
XLI Installer UI — beautiful terminal rendering for dependency installation.

Works through UiPort so it renders correctly in:
- CLI (TerminalUi): Unicode progress bars with colors
- TUI (curses): native progress widgets
- Neovim: via RPC notifications

This module provides enhanced rendering on top of the core DepsInstaller.
"""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from xli.ui.port import UiPort
    from xli.core.deps_installer import DependencyInfo


# ==========================================================================
# ANSI COLORS (safe, no dependencies)
# ==========================================================================

class _C:
    """Minimal ANSI color helper. Degrades gracefully if not a TTY."""
    _enabled = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()

    @classmethod
    def bold(cls, s: str) -> str:
        return f"\033[1m{s}\033[0m" if cls._enabled else s

    @classmethod
    def green(cls, s: str) -> str:
        return f"\033[32m{s}\033[0m" if cls._enabled else s

    @classmethod
    def cyan(cls, s: str) -> str:
        return f"\033[36m{s}\033[0m" if cls._enabled else s

    @classmethod
    def yellow(cls, s: str) -> str:
        return f"\033[33m{s}\033[0m" if cls._enabled else s

    @classmethod
    def red(cls, s: str) -> str:
        return f"\033[31m{s}\033[0m" if cls._enabled else s

    @classmethod
    def dim(cls, s: str) -> str:
        return f"\033[2m{s}\033[0m" if cls._enabled else s


# ==========================================================================
# GRADIENT LINE (via rich)
# ==========================================================================

def render_gradient_line(width: int = 60, text: str = "") -> str:
    """Render a thin gradient purple line using rich.

    Falls back to a simple Unicode line if rich is not installed.
    Colors transition from dark purple to bright violet/magenta.
    """
    try:
        from rich.console import Console
        from rich.text import Text
        import io

        buf = io.StringIO()
        console = Console(file=buf, force_terminal=True, width=width + 20)

        # Purple gradient color stops (hex)
        colors = [
            "#2d0a4e",  # deep dark purple
            "#4a1172",  # dark purple
            "#6b1d9e",  # medium purple
            "#8b2fc0",  # purple
            "#a855f7",  # bright violet
            "#c084fc",  # light violet
            "#d8b4fe",  # pale violet
            "#e9d5ff",  # almost white violet
        ]

        line_text = Text()
        chars = "─" * width if not text else f"{'─' * ((width - len(text) - 2) // 2)} {text} {'─' * ((width - len(text) - 2) // 2)}"

        # Distribute characters across gradient colors
        char_list = list(chars)
        for i, ch in enumerate(char_list):
            # Map character index to color index
            color_idx = int(i / max(len(char_list), 1) * len(colors))
            color_idx = min(color_idx, len(colors) - 1)
            line_text.append(ch, style=f"bold {colors[color_idx]}")

        console.print(line_text)
        return buf.getvalue().rstrip()

    except ImportError:
        # Fallback without rich
        if text:
            pad = (width - len(text) - 2) // 2
            return f"{'─' * pad} {text} {'─' * pad}"
        return "─" * width


def print_gradient_line(width: int = 60, text: str = "") -> None:
    """Print gradient line directly to stdout."""
    print(render_gradient_line(width, text))


# ==========================================================================
# PROGRESS BAR RENDERER
# ==========================================================================

# Spinner frames for animation
SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]


def render_progress_bar(
    percent: int,
    width: int = 30,
    fill_char: str = "█",
    empty_char: str = "░",
    head_char: str = "▓",
) -> str:
    """Render a Unicode progress bar.

    Example output: ████████████░░░░░░░░░░░░░░░░░░ 40%
    """
    filled = int(width * percent / 100)
    empty = width - filled

    if filled > 0 and empty > 0:
        bar = _C.green(fill_char * (filled - 1)) + _C.cyan(head_char) + _C.dim(empty_char * empty)
    elif filled == width:
        bar = _C.green(fill_char * width)
    else:
        bar = _C.dim(empty_char * width)

    pct_str = f"{percent:3d}%"
    return f"[{bar}] {pct_str}"


def render_stage_header(stage: str, icon: str = "") -> str:
    """Render a stage header line."""
    icons = {
        "analyze": "🔍",
        "describe": "📋",
        "confirm": "❓",
        "download": "⬇️ ",
        "install": "🔧",
        "verify": "✅",
    }
    stage_icon = icon or icons.get(stage, "⚙️ ")
    return _C.bold(f"  {stage_icon} {stage.upper()}")


# ==========================================================================
# DEPENDENCY INFO CARD
# ==========================================================================

def render_dep_card(dep: DependencyInfo) -> str:
    """Render a beautiful info card for a dependency with gradient lines."""
    width = 54
    top_line = render_gradient_line(width + 4)
    bot_line = render_gradient_line(width + 4)

    lines = []
    lines.append(f"  {top_line}")
    lines.append(f"  │ {_C.bold('📦 ' + dep.name):<{width}} │")
    lines.append(f"  │ {'':<{width}} │")

    fields = [
        ("Description", dep.description or "N/A"),
        ("Why needed", dep.why_needed or "Required by XLI"),
        ("Used by", ", ".join(dep.required_by) if dep.required_by else "core"),
        ("Install", f"pip install {dep.install_spec}"),
    ]

    for label, value in fields:
        max_val_len = width - len(label) - 5
        val_str = value[:max_val_len] if len(value) > max_val_len else value
        line = f"{_C.cyan(label):>14} : {val_str}"
        visible_len = len(label) + 3 + len(val_str)
        padding = width - visible_len
        if padding < 0:
            padding = 0
        lines.append(f"  │ {line}{' ' * padding} │")

    lines.append(f"  {bot_line}")
    return "\n".join(lines)


# ==========================================================================
# INSTALLATION SUMMARY
# ==========================================================================

def render_summary(results: dict[str, bool]) -> str:
    """Render final installation summary with gradient separator."""
    sep = render_gradient_line(50)
    lines = ["", f"  {sep}", _C.bold("  Installation Summary"), f"  {sep}", ""]

    for name, success in results.items():
        if success:
            lines.append(f"    {_C.green('✅')} {name}")
        else:
            lines.append(f"    {_C.red('❌')} {name} {_C.dim('(skipped/failed)')}")

    ok = sum(1 for v in results.values() if v)
    fail = sum(1 for v in results.values() if not v)
    lines.append("")
    lines.append(f"    Total: {_C.green(str(ok))} installed, {_C.red(str(fail))} failed/skipped")
    lines.append(f"  {sep}")
    lines.append("")
    return "\n".join(lines)


# ==========================================================================
# HIGH-LEVEL API
# ==========================================================================

def install_dependencies(
    packages: list[str],
    ui: UiPort,
    registry: dict | None = None,
) -> dict[str, bool]:
    """One-call convenience function: check, describe, confirm, install.

    Uses DepsInstaller internally but enhances output through the UiPort.
    """
    from xli.core.deps_installer import DepsInstaller

    # Show banner with gradient line
    ui.display(
        _C.bold("\n  🔧 XLI Dependency Manager\n") + "  " + render_gradient_line(50) + "\n",
        title=None,
    )

    installer = DepsInstaller(ui=ui, registry=registry)

    # Override progress to use our fancy renderer
    original_progress = ui.progress

    def enhanced_progress(percent: int, message: str = "") -> None:
        bar = render_progress_bar(percent)
        # Extract stage from message if present
        stage = message.split(":")[0] if ":" in message else "working"
        full_line = f"\r  {bar} │ {message}"
        original_progress(percent, full_line)

    ui.progress = enhanced_progress  # type: ignore[method-assign]

    try:
        results = installer.check_and_install(packages)
    finally:
        ui.progress = original_progress  # type: ignore[method-assign]

    # Show summary
    ui.display(render_summary(results))
    return results
